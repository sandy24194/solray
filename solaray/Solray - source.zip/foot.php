<script src="external/js/jquery.js"></script>
<script src="external/js/script.js"></script>
<script src="external/js/products.js"></script>